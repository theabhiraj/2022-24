#include<iostream>
#include<conio.h>
#include<windows.h>
#include<unistd.h>
using namespace std;
void welcome();
void jio();
 /*int main()
 {  
    welcome();   
    getch();
    return 0;
  } 
  */
  
  
  
  void welcome()
  {
    
  cout<<"\n\n\n\n\n\n\n ";
  system("color A");
  cout<<"\t\t\t\t\t\t                              ______                  ______     ______                 _______             "<<endl;
  cout<<"\t\t\t\t\t\t   \\                      /  |          |            |          |      |   |\\      /|   | "<<endl; 
  cout<<"\t\t\t\t\t\t    \\                    /   |          |            |          |      |   | \\    / |   |       "<<endl; 
  cout<<"\t\t\t\t\t\t     \\        /\\        /    |          |            |          |      |   |  \\  /  |   |       "<<endl;
  cout<<"\t\t\t\t\t\t      \\      /  \\      /     |______    |            |          |      |   |   \\/   |   |______   "<<endl;
  cout<<"\t\t\t\t\t\t       \\    /    \\    /      |          |            |          |      |   |        |   |       "<<endl;
  cout<<"\t\t\t\t\t\t        \\  /      \\  /       |          |            |          |      |   |        |   |        "<<endl;
  cout<<"\t\t\t\t\t\t         \\/        \\/        |_______   |________    |______    |______|   |        |   |________  "<<endl;
  cout<<endl;
  sleep(3);
  system("color E");
  cout<<endl<<endl<<endl<<endl<<endl;
  cout<<"\t\t\t\t\t\t                             ____________      _______     "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |       |    "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |       |    "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |       |    "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |       |    "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |       |    "<<endl;
  cout<<"\t\t\t\t\t\t                                   |          |_______|    "<<endl;
  sleep(2);
  system("color B");
  cout<<endl<<endl<<endl<<endl<<endl;
  jio();
  sleep(2); 
  system("color BC");
  sleep(1);
  system("color 7");
  }
 
 void jio()
 {
 
  cout<<"\t\t\t\t\t\t           _________       _______  \t         _______             _                                            "<<endl;
  cout<<"\t\t\t\t\t\t               |      |   |       | \t        |        |          / \\        |\\      |   |    /                         "<<endl;
  cout<<"\t\t\t\t\t\t               |      |   |       | \t        |         |        /   \\       | \\     |   |   /                            "<<endl;
  cout<<"\t\t\t\t\t\t               |      |   |       | \t        |        |        /     \\      |  \\    |   |  /                           "<<endl;
  cout<<"\t\t\t\t\t\t               |      |   |       | \t        |  -----         /-------\\     |   \\   |   | /                                 "<<endl;
  cout<<"\t\t\t\t\t\t               |      |   |       | \t        |        |      /         \\    |    \\  |   |  \\                             "<<endl;
  cout<<"\t\t\t\t\t\t         |     |      |   |       | \t        |         |    /           \\   |     \\ |   |   \\                               "<<endl;
  cout<<"\t\t\t\t\t\t         |_____|      |   |_______| \t        |_______ |    /             \\  |      \\|   |    \\                                  "<<endl;
 
 }
  
